<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __Construct()
	{
		parent::__Construct();
        $this->load->model('M_admin');
		if (!$this->ion_auth->logged_in()){redirect('auth/login', 'refresh');}
	}

	public function index()
	{
        $data = array(
            'title'     => 'GIS Dokter | Dashboard',
            'page'      =>  'Dashboard',
        );
		$this->template->load('back-end/_template','back-end/v_dashboard',$data);
	}

	public function profil(){
        $data = array(
            'title'     =>  'GIS Dokter | Profil',
            'page'      =>  'Profil',
        );
        $id  = $this->input->post('id');
		if(isset($_POST['update'])){
            $data = array(
                'judul'         => $this->input->post('judul'),
                'isi_profil'    => $this->input->post('isi'),
            );
            $this->M_admin->ubah_profil($data,$id);
            $this->session->set_flashdata('sukses_edit', 'Data Berhasil Diubah');
            redirect('admin/profil');
        }else{
            $data['p'] = $this->M_admin->profil()->row_array();
            $this->template->load('back-end/_template','back-end/v_profil',$data);
        }
	}

	public function dokter(){
		$data = array(
            'title'     => 'GIS Dokter | Dokter',
            'page' 	    => 'Dokter',
            'dokter'	=> $this->M_admin->list_dokter()->result(),
        );
        $this->template->load('back-end/_template','back-end/dokter',$data);
	}

    public function detail_dokter($id_dokter){
        

        $data = array(
            'title'             => 'GIS Dokter | Detail Dokter',
            'page'              => 'Detail Dokter',
            'detail_dokter'     => $this->M_admin->detail_dokter($id_dokter)->row_array(),
        );

        $this->load->library('googlemaps');

        $rute = $this->M_admin->rute($id_dokter);
        $config['center'] = '6.8929251, 109.3864994';
        $config['zoom'] = 'auto';
        $this->googlemaps->initialize($config);

        $marker = array();
        $marker['position'] = $rute->latitude.','.$rute->longitude;
        $this->googlemaps->add_marker($marker);
        $data['map'] = $this->googlemaps->create_map();

        // print_r($data);
        $this->template->load('back-end/template','back-end/detail_dokter',$data);
    }

	public function tampil_tambah_dokter(){
		$data = array(
            'title' 	=> 'GIS Dokter | Tambah Dokter',
            'page'      => 'Tambah Dokter',
            'kategori'	=> $this->M_admin->list_kategori()->result(),
        );
        $this->template->load('back-end/_template','back-end/tambah_dokter',$data);
	}

	public function simpan_dokter(){
        $no_sip     = $this->input->post('no_sip');
		$cek_no_sip = $this->M_admin->cek_no_sip($no_sip);
		if ($cek_no_sip->num_rows() > 0) {
            $this->session->set_flashdata('error_no_sip', 'No SIP Sudah Digunakan');
            redirect('admin/tambah_dokter');
        } else {
        	$data = array(
                'id_dokter'         => $this->input->post('id_dokter'),
                'no_sip'            => $this->input->post('no_sip'),
                'nama'              => $this->input->post('nama'),
                'jenis_kelamin'     => $this->input->post('jenis_kelamin'),
                'id_kategori'       => $this->input->post('id_kategori'),
                'hari_praktek'      => $this->input->post('hari_praktek'),
                'jam_praktek'       => $this->input->post('jam_praktek'),
                'hari_praktek'      => $this->input->post('hari_praktek'),
                'pelayanan'         => $this->input->post('pelayanan'),
                'alamat'            => $this->input->post('alamat'),
                'hp'                => $this->input->post('hp'),
                'latitude'          => $this->input->post('latitude'),
                'longitude'         => $this->input->post('longitude'),
                'foto'              => "file_" . time() . '.' . end(explode('.', $_FILES['foto']['name']))
            );
            if (!empty($_FILES['foto']['name'])) {
                $upload = $this->_do_upload();
                //$data['foto'] = $upload;
            }
            $this->M_admin->simpan_dokter($data);
            $this->session->set_flashdata('sukses', 'Data Berhasil Ditambahkan');
            // print_r($data);
            redirect('admin/dokter');
        }
	}

    public function tampil_ubah_dokter($id_dokter){
        $data = array(
            'title'         => 'GIS Dokter | Ubah Dokter',
            'page'          => 'Ubah Dokter',
            'dokter'        => $this->M_admin->cari_dokter($id_dokter)->row_array(),
            'kategori'      => $this->M_admin->list_kategori()->result(),
        );
        $this->template->load('back-end/_template','back-end/ubah_dokter',$data);
    }

    public function coba(){
        $id_dokter = $this->input->post('id_dokter');

        $data = array(
            // 'id_dokter'         => $this->input->post('id_dokter'),
            'no_sip'            => $this->input->post('no_sip'),
            'nama'              => $this->input->post('nama'),
            'jenis_kelamin'     => $this->input->post('jenis_kelamin'),
            'id_kategori'       => $this->input->post('id_kategori'),
            'hari_praktek'      => $this->input->post('hari_praktek'),
            'jam_praktek'       => $this->input->post('jam_praktek'),
            'hari_praktek'      => $this->input->post('hari_praktek'),
            'pelayanan'         => $this->input->post('pelayanan'),
            'alamat'            => $this->input->post('alamat'),
            'hp'                => $this->input->post('hp'),
            'latitude'          => $this->input->post('latitude'),
            'longitude'         => $this->input->post('longitude'),
        );
        if (!empty($_FILES['foto']['name'])) {
            $person = $this->M_admin->coba($id_dokter)->row_array();
            unlink('uploads/instansi/' . $person['foto']);
            $data['foto'] = "file_" . time() . '.' . end(explode('.', $_FILES['foto']['name']));
            $upload = $this->_do_upload();

             $this->M_admin->edit_dokter($data, $id);
        }
        if (empty($_FILES['foto']['name'])) {
            $this->M_admin->edit_dokter($data, $id);
        }
        $this->M_admin->edit_dokter($data, $id_dokter);
        // $t = $this->M_admin->ubah_dokter($data, $id);
        $this->session->set_flashdata('sukses_edit', 'Data Berhasil Diubah');
        redirect('admin/dokter');
        // print_r($id_dokter);
    }

    public function hapus_dokter(){
        $id_dokter  = $this->uri->segment('3');
        $person     = $this->M_admin->coba($id_dokter)->row_array();
        unlink('uploads/instansi/' . $person['foto']);
        $this->M_admin->hapus_dokter($id_dokter);
        $this->session->set_flashdata('sukses_hapus', 'Data Berhasil Dihapus');
        redirect('admin/dokter');
        // print_r($id);
    }

	//-------Upload Foto dokter--------------//
	public function _do_upload() {
        $nmfile = "file_" . time() . '.' . end(explode('.', $_FILES['foto']['name']));
        $path = './uploads/instansi/';
        $config['upload_path'] = $path;
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 1000; //set max size allowed in Kilobyte
        $config['file_name'] = $nmfile;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('foto')) { //upload and validate
            $error = array('error' => $this->upload->display_errors());
        }

        return $this->upload->data('file_name');
    }

    public function kategori(){
        $data = array(
            'title'         => 'GIS Dokter | Kategori',
            'page'          => 'Kategori',
            'kategori'      =>  $this->M_admin->list_kategori()->result(),
        );
        $this->template->load('back-end/_template','back-end/kategori',$data);
    }

    public function simpan_kategori(){
        $data = array(
            'id_kategori'       => $this->input->post('id_kategori'),
            'nama_kategori'     => $this->input->post('nama_kategori'),
            'icon'              => "file_" . time() . '.' . end(explode('.', $_FILES['icon']['name']))
        );
        if (!empty($_FILES['icon']['name'])) {
                $upload = $this->upload_kategori();
                //$data['foto'] = $upload;
            }
        $this->M_admin->simpan_kategori($data);
        $this->session->set_flashdata('sukses', 'Data Berhasil Ditambahkan');
        // print_r($data);
        redirect('admin/kategori');
    }

    public function tampil_edit_kategori($id_kategori){
        $data = array(
            'title'                 => 'GIS Kategori | Ubah Kategori',
            'page'                  => 'Ubah Kategori',
            'kategori'              =>  $this->M_admin->list_kategori()->result(),
            'kategori_detail'       =>  $this->M_admin->cari_kategori($id_kategori)->row_array(),
        );
        $this->template->load('back-end/_template','back-end/ubah_kategori',$data);
    }

    public function ubah_kategori(){
        $id_kategori = $this->input->post('id_kategori');

        $data = array(
            'nama_kategori'        => $this->input->post('nama_kategori'),
        );
        if (!empty($_FILES['icon']['name'])) {
            $person = $this->M_admin->coba2($id_kategori)->row_array();
            unlink('uploads/icon/' . $person['icon']);
            $data['icon'] = "file_" . time() . '.' . end(explode('.', $_FILES['icon']['name']));
            $upload = $this->upload_kategori();

             $this->M_admin->ubah_kategori($data, $id_kategori);
        }
        if (empty($_FILES['icon']['name'])) {
            $this->M_admin->ubah_kategori($data, $id_kategori);
        }
        $this->M_admin->ubah_kategori($data, $id_kategori);
        $this->session->set_flashdata('sukses_edit', 'Data Berhasil Diubah');
        redirect('admin/kategori');
        // print_r($id_kategori);
    }

    public function hapus_kategori(){
        $id_kategori    = $this->uri->segment('3');
        $person         = $this->M_admin->coba2($id_kategori)->row_array();
        unlink('uploads/icon/' . $person['icon']);
        $this->M_admin->hapus_kategori($id_kategori);
        $this->session->set_flashdata('sukses_hapus', 'Data Berhasil Dihapus');
        redirect('admin/kategori');
        // print_r($id);
    }

    //-------Upload Foto dokter--------------//
    public function upload_kategori() {
        $nmfile = "file_" . time() . '.' . end(explode('.', $_FILES['icon']['name']));
        $path = './uploads/icon/';
        $config['upload_path'] = $path;
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 1000; //set max size allowed in Kilobyte
        $config['file_name'] = $nmfile;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('icon')) { //upload and validate
            $error = array('error' => $this->upload->display_errors());
        }

        return $this->upload->data('file_name');
    }

    public function berita(){
        $data = array(
            'title'         => 'GIS Dokter | Berita',
            'page'          => 'Berita',
            'berita'        =>  $this->M_admin->list_berita()->result(),
        );
        $this->template->load('back-end/_template','back-end/berita',$data);
    }

    public function tampil_tambah_berita(){
        $data = array(
            'title'     => 'GIS Dokter | Tambah Berita',
            'page'      => 'Tambah Berita',
        );
        $this->template->load('back-end/_template','back-end/tambah_berita',$data);
    }

    public function simpan_berita(){
        $data = array(
            'id_berita'         => $this->input->post('id_berita'),
            'judul'             => $this->input->post('judul'),
            'isi_berita'        => $this->input->post('isi_berita'),
            'gambar'            => "file_" . time() . '.' . end(explode('.', $_FILES['gambar']['name'])),
            'tanggal'           => date('Y-m-d'),
            'penulis'           => 'admin',
            'dibaca'            => '0',
        );
        if (!empty($_FILES['gambar']['name'])) {
                $upload = $this->upload_berita();
                //$data['foto'] = $upload;
            }
        $this->M_admin->simpan_berita($data);
        $this->session->set_flashdata('sukses', 'Data Berhasil Ditambahkan');
        // print_r($data);
        redirect('admin/berita');
    }

    public function tampil_edit_berita($id_berita){
        $data = array(
            'title'                 => 'GIS Kategori | Ubah Berita',
            'page'                  => 'Ubah Berita',
            'berita'                =>  $this->M_admin->detail_berita($id_berita)->row_array(),
        );
        $this->template->load('back-end/_template','back-end/ubah_berita',$data);
    }

    public function ubah_berita(){
        $id_berita = $this->input->post('id_berita');

        $data = array(
            'judul'             => $this->input->post('judul'),
            'isi_berita'        => $this->input->post('isi_berita'),
        );
        if (!empty($_FILES['gambar']['name'])) {
            $person = $this->M_admin->coba3($id_berita)->row_array();
            unlink('uploads/berita/' . $person['gambar']);
            $data['gambar'] = "file_" . time() . '.' . end(explode('.', $_FILES['gambar']['name']));
            $upload = $this->upload_berita();

             $this->M_admin->ubah_berita($data, $id_berita);
        }
        if (empty($_FILES['gambar']['name'])) {
            $this->M_admin->ubah_berita($data, $id_berita);
        }
        $this->M_admin->ubah_berita($data, $id_berita);
        $this->session->set_flashdata('sukses_edit', 'Data Berhasil Diubah');
        redirect('admin/berita');
        // print_r($person);
    }

    public function upload_berita() {
        $nmfile = "file_" . time() . '.' . end(explode('.', $_FILES['gambar']['name']));
        $path = './uploads/berita/';
        $config['upload_path'] = $path;
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 1000; //set max size allowed in Kilobyte
        $config['file_name'] = $nmfile;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('gambar')) { //upload and validate
            $error = array('error' => $this->upload->display_errors());
        }

        return $this->upload->data('file_name');
    }

    public function hapus_berita(){
        $id_berita      = $this->uri->segment('3');
        $person         = $this->M_admin->coba3($id_berita)->row_array();
        unlink('uploads/berita/' . $person['gambar']);
        $this->M_admin->hapus_berita($id_berita);
        $this->session->set_flashdata('sukses_hapus', 'Data Berhasil Dihapus');
        redirect('admin/berita');
        // print_r($id);
    }

    public function komentar()
    {
        $data = array(
            'title'     => 'GIS Dokter | Komentar',
            'page'      => 'Komentar',
            'k'         => $this->M_admin->komentar()->result(),
        );
        $this->template->load('back-end/_template','back-end/v_komentar',$data);
    }

    public function hapus_komentar()
    {
        $id_komentar      = $this->uri->segment('3');
        $this->M_admin->hapus_komentar($id_komentar);
        $this->session->set_flashdata('sukses_hapus', 'Data Berhasil Dihapus');
        redirect('admin/komentar');
    }

}

/* End of file Admin.php */
/* Location: ./application/controllers/Admin.php */