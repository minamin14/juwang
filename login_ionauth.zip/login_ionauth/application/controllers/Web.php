<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('M_web');
        $this->load->model('M_admin');
    }


	public function index()
	{
		$data = array(
            'list_dokter' => $this->M_web->list_dokter(),
            'bp' 		  => $this->M_web->berita_populer(),
            'bt'          => $this->M_web->berita_terbaru(),
        );
		$this->template->load('front-end/_template','front-end/v_home',$data);
	}

	public function berita()
	{
		$data = array(
            'berita'      => $this->M_web->berita(),
            'bp' 		  => $this->M_web->berita_populer(),
            'bt'          => $this->M_web->berita_terbaru(),
        );
		$this->template->load('front-end/_template','front-end/v_berita',$data);
	}

	public function beritadetail($id)
	{
		$data = array(
            'berita'      => $this->M_web->berita(),
            'bp' 		  => $this->M_web->berita_populer(),
            'bt'          => $this->M_web->berita_terbaru(),
        );
        $berita = $this->M_web->detail_berita($id)->row_array();
		$dibaca = $berita['dibaca'];
		$this->db->update('berita',array('dibaca'=>$dibaca + 1),array("id_berita"=>$id));
		$data['bo'] = $this->M_web->detail_berita($id)->row_array();
		$this->template->load('front-end/_template','front-end/v_detail_berita',$data);
	}

	public function profil()
	{
		$data = array(
            'p'           => $this->M_web->profil()->row_array(),
            'bp' 		  => $this->M_web->berita_populer(),
            'bt'          => $this->M_web->berita_terbaru(),
        );
		$this->template->load('front-end/_template','front-end/v_profil',$data);
	}

	public function dokter()
	{
		$data = array(
            'do'          => $this->M_web->dokter()->result(),
            'bp' 		  => $this->M_web->berita_populer(),
            'bt'          => $this->M_web->berita_terbaru(),
        );
		$this->template->load('front-end/_template','front-end/v_dokter',$data);
	}

	public function detail_dokter($id_dokter){
		$data = array(
            'dokter'      => $this->M_web->detail_dokter($id_dokter)->row_array(),
            'bp' 		  => $this->M_web->berita_populer(),
            'bt'          => $this->M_web->berita_terbaru(),
        );
	}

	public function rute($id_dokter){
		$data = array(
            'title'             => 'GIS Dokter | Detail Dokter',
            'page'              => 'Detail Dokter',
            'detail_dokter'     => $this->M_admin->detail_dokter($id_dokter)->row_array(),
        );


        $this->load->library('googlemaps');
        $rute = $this->M_admin->rute($id_dokter);
        
        $config['zoom']='auto';
        $config['language']='Indonesia';
        $config['directions'] = TRUE;
        $config['directionsStart'] = 'auto';
        $config['directionsEnd'] = $rute->latitude.','.$rute->longitude;
        $config['directionsDivID'] = 'directionsDiv';
        $this->googlemaps->initialize($config);

        $marker = array();
        $marker['position']=$rute->latitude.','.$rute->longitude;
        $marker['infowindow_content']='<div class="text-center"><img src="'.base_url('uploads/instansi/').$rute->foto.'"width="190" height="100" /><br /><br /><p>'.$rute->nama.'<br/>'.$rute->alamat.'</p></div>';
        $marker['animation']='DROP';
        $marker['icon'] = 'http://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=D|9999FF|000000';
        $this->googlemaps->add_marker($marker);

        $data['map']=$this->googlemaps->create_map();
        $this->template->load('front-end/_template','front-end/v_detailrute',$data);
	}

	public function komentar()
	{
		if(isset($_POST['kirim'])) {
			$data = array(
				'nama' 		=> $this->input->post('nama'),
				'email' 	=> $this->input->post('email'),
				'website' 	=> $this->input->post('website'),
				'komentar' 	=> $this->input->post('komentar'),
				);
			$this->db->insert('komentar',$data);
			redirect('web/komentar');
        }else{
        	$data = array(
            'k'           => $this->M_web->komentar(),
            'bp' 		  => $this->M_web->berita_populer(),
            'bt'          => $this->M_web->berita_terbaru(),
        );
			$this->template->load('front-end/_template','front-end/v_komentar',$data);
        }
	}
}
