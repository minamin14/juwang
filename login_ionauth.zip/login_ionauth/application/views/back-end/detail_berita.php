<section class="content-header">
    <h1>
        <?= $page;?>
    </h1>
</section>

<!-- Main content -->
<section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-default">
        <div class="box-header with-border">
            <h3 class="box-title">Detail Berita</h3>

            <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
            </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">

            <form role="form">
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-bordered table-striped">
                            <tbody>
                            <h4><?php echo $data_pengumuman['judul']; ?> </h4>
                                <hr/>
                                <?php echo $data_pengumuman['detail_pengumuman']; ?>
                                
                            </tbody>
                        </table>    
                    </div>
                    <!-- /.col -->
                    <!-- /.col -->
                </div>

            </form>
            <!-- /.row -->
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
            <?php echo anchor('admin/pengumuman', 'Kembali', array('class' => 'btn btn-danger')); ?>
        </div>
    </div>
    <!-- /.box -->
</section>
