<section class="content-header">
    <h1>
        <?= $page;?>
    </h1>
</section>

<!-- Main content -->
<section class="content">
    <?php if ($this->session->flashdata('sukses')) { ?>
        <div class="alert alert-info alert-dismissable" role="">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-save"> <?php echo $this->session->flashdata('sukses'); ?></i></h5>
        </div>
    <?php }; ?>
    <?php if ($this->session->flashdata('sukses_hapus')) { ?>
        <div class="alert alert-info alert-dismissable" role="">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-trash"> <?php echo $this->session->flashdata('sukses_hapus'); ?></i></h5>
        </div>
    <?php }; ?>
    <?php if ($this->session->flashdata('sukses_edit')) { ?>
        <div class="alert alert-info alert-dismissable" role="">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-edit"> <?php echo $this->session->flashdata('sukses_edit'); ?></i></h5>
        </div>
    <?php }; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box box-success">

                <!-- /.box-header -->
                <div class="box-body">
                    <div class="box-header">
                        <!-- <h5 class="box-title">Data Table With Full Features</h5>-->
                        <?php echo anchor('admin/tampil_tambah_dokter/', '<i class="glyphicon glyphicon-plus"></i>Tambah Data', array('class' => 'btn btn-primary btn-sm')); ?>
                    </div>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="15px">No</th>
                                <th>No SIP</th>
                                <th>Nama Dokter</th>
                                <th>Alamat</th>
                                <th>Praktek</th>
                                <th width="100px">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($dokter as $r) :
                                ?>
                                <tr>
                                    <td><?=$no++; ?></td>
                                    <td><?=$r->no_sip ?></td>
                                    <td><?=$r->nama ?></td>
                                    <td><?=$r->alamat ?></td>
                                    <td><?=$r->nama_kategori ?></td>
                                    <td>
                                        <div class="btn-group">
                                          <a class="btn btn-success btn-sm btn-flat" href="<?=base_url().'admin/detail_dokter/'.$r->id_dokter ?>"><i class="fa fa-search"></i> </a>
                                          <a class="btn btn-success btn-sm btn-flat" href="<?=base_url().'admin/tampil_ubah_dokter/'.$r->id_dokter ?>"><i class="fa fa-edit"></i> </a>
                                          <a class="btn btn-danger btn-sm btn-flat btn-hapus" data-id="<?= $r->id_dokter ?>" data-nama="<?= $r->nama ?>"><i class="fa fa-trash"></i> </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<script src="<?=base_url().'assets/' ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<script>
    
    $('.btn-hapus').click(function () {
        var no = $(this).attr('data-id');
        var nama = $(this).attr('data-nama');
        swal({
            title: "Apakah anda yakin?",
            text: "Anda akan menghapus data : " + no + " - " + nama,
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Ya, Hapus!",
            closeOnConfirm: false
        },
                function () {
                    window.location.href = "<?= base_url() ?>admin/hapus_dokter/" + no;
                });
    });

</script> 