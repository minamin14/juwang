<section class="content-header">
    <h1>
        <?= $page;?>
    </h1>
</section>

<!-- Main content -->
<section class="content">
    <?php if ($this->session->flashdata('sukses')) { ?>
        <div class="alert alert-info alert-dismissable" role="">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-save"> <?php echo $this->session->flashdata('sukses'); ?></i></h5>
        </div>
    <?php }; ?>
    <?php if ($this->session->flashdata('sukses_hapus')) { ?>
        <div class="alert alert-info alert-dismissable" role="">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-trash"> <?php echo $this->session->flashdata('sukses_hapus'); ?></i></h5>
        </div>
    <?php }; ?>
    <?php if ($this->session->flashdata('sukses_edit')) { ?>
        <div class="alert alert-info alert-dismissable" role="">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-edit"> <?php echo $this->session->flashdata('sukses_edit'); ?></i></h5>
        </div>
    <?php }; ?>
    <div class="row">
      <div class="col-sm-5">
        <div class="box box-success">
            <div class="box-header with-border">
                <h3 class="box-title">Tambah Kategori Lokasi</h3>
            </div>
            <form role="form" method="POST" enctype="multipart/form-data" action="<?= base_url() ?>admin/simpan_kategori">
              <div class="box-body">
                  <div class="form-group">
                    <label>Kategori Praktek</label>
                    <input name="nama_kategori" type="text" class="form-control" placeholder="Nama Kategori" required="">
                  </div>
                  <div class="form-group"> 
                      <label>Icon</label>
                      <img id="preview_gambar" src="<?= base_url() ?>uploads/preview.png" alt="" class="img-responsive thumbnail" />
                  </div>
                  <div class="form-group">                                
                      <input style="padding:0px" type="file" name="icon" onchange="readURL(this);"  id="uni_file" class="uni_style form-control" accept="image/*"/>
                      <p class="help-block">Max size 1MB</p>
                  </div>
              </div>
              <div class="box-footer">
                  <button name="simpan" type="submit" class="btn btn-success btn-flat"><i class="fa fa-save"></i> Simpan</button>
                  <button type="reset" class="btn btn-warning btn-flat"><i class="fa fa-retweet"></i> Reset</button>
              </div>
          </form>
        </div>
      </div>
        <div class="col-sm-7">
            <div class="box box-success">

                <!-- /.box-header -->
                <div class="box-body">
                    <div class="box-header">
                        <!-- <h5 class="box-title">Data Table With Full Features</h5>-->
                        <h3 class="box-title">Data Kategori Praktek</h3>
                    </div>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="15px">No</th>
                                <th>Nama Kategori</th>
                                <th>Icon</th>
                                <th width="100px">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($kategori as $r) :
                                ?>
                                <tr>
                                    <td><?=$no++; ?></td>
                                    <td><?=$r->nama_kategori ?></td>
                                    <td><img src="<?=base_url().'uploads/icon/'.$r->icon ?>"></td>
                                    <td>
                                        <div class="btn-group">
                                          <a class="btn btn-success btn-sm btn-flat" href="<?=base_url().'admin/tampil_edit_kategori/'.$r->id_kategori ?>"><i class="fa fa-edit"></i> </a>
                                          <a class="btn btn-danger btn-sm btn-flat btn-hapus" data-id="<?= $r->id_kategori ?>" data-nama="<?= $r->nama_kategori ?>"><i class="fa fa-trash"></i> </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<script src="<?=base_url().'assets/' ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<script>
    
    $('.btn-hapus').click(function () {
        var no = $(this).attr('data-id');
        var nama = $(this).attr('data-nama');
        swal({
            title: "Apakah anda yakin?",
            text: "Anda akan menghapus data : " + no + " - " + nama,
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Ya, Hapus!",
            closeOnConfirm: false
        },
                function () {
                    window.location.href = "<?= base_url() ?>admin/hapus_kategori/" + no;
                });
    });
    function readURL(input)
     { // Mulai membaca inputan gambar
        if (input.files && input.files[0]) {
            var reader = new FileReader(); // Membuat variabel reader untuk API FileReader

            reader.onload = function (e) { // Mulai pembacaan file
                $('#preview_gambar') // Tampilkan gambar yang dibaca ke area id #preview_gambar
                        .attr('src', e.target.result)
                        .height(200)
                        .width(200);

            };

            reader.readAsDataURL(input.files[0]);
        }
     }
</script> 