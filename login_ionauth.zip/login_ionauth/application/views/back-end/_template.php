<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= $title;?></title>
  <link href="<?php echo base_url().'assets/dist/img/favorit.png' ?>" rel="shortcut icon" type="image/ico" />
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?=base_url().'assets/' ?>bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?=base_url().'assets/' ?>plugins/select2/select2.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?=base_url().'assets/' ?>plugins/datatables/dataTables.bootstrap.css">
  <!-- CKEditor -->
  <script type="text/javascript" src="<?=base_url().'assets/' ?>plugins/ckeditor/ckeditor.js"></script>
  <script type="text/javascript" src="<?=base_url().'assets/' ?>plugins/ckeditor/style.js"></script>
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url().'assets/' ?>dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="<?=base_url().'assets/' ?>dist/css/sweetalert.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?=base_url().'assets/' ?>dist/css/skins/_all-skins.min.css">
  <script type="text/javascript">
  var peta;
  var foto = new Array();
  var nama     = new Array();
  var kategori_praktek = new Array();
  var alamat   = new Array();
  var hp   = new Array();
  var x        = new Array();
  var y        = new Array();
  var i;
  var url;
  var gambar_tanda;
  var foto;
  var baseurl  = "<?php echo base_url() ?>";

  function peta_awal() {
      var purwakarta = new google.maps.LatLng(-6.8929251,109.3864994);

      // ini buat ngilangin icon place bawaan google maps
      var myStyles =[
      {
          featureType: "poi",
          elementType: "labels",
          stylers: [
                { visibility: "off" }
          ]
      }
      ];

      var petaoption = {
          zoom: 16,
          center: purwakarta,
          mapTypeId: google.maps.MapTypeId.ROADMAP,
          styles: myStyles 
          };

      peta = new google.maps.Map(document.getElementById("map_canvas"),petaoption);

      // panggil pungsi ini buat nampilin markernya di peta
      ambildatabase();

  }

  function ambildatabase(){
      // kita bikin dulu array marker dan content info
      var markers = [];
      var info = [];
      
      <?php
      // koneksi database
      // $link   = mysql_connect('localhost','root','');
      // mysql_select_db('googlemaps_multiicon', $link);

      $query = $this->db->query("SELECT  d.nama, d.foto, d.alamat, d.hp, d.latitude, d.longitude, k.nama_kategori, k.icon
                                FROM dokter as d, kategori_praktek as k
                                WHERE d.id_kategori=k.id_kategori");
      $i = 0;
      $js = "";

      // kita lakuin looping datanya disini
      // while ($value = mysql_fetch_assoc($query)) {
      foreach ($query->result() as $value) {

      $js .= 'nama['.$i.'] = "'.$value->nama.'";
              foto['.$i.'] = "'.base_url().'uploads/instansi/'.$value->foto.'";
              alamat['.$i.'] = "'.$value->alamat.'";
              hp['.$i.'] = "'.$value->hp.'";
              x['.$i.'] = "'.$value->latitude.'";
              y['.$i.'] = "'.$value->longitude.'";
              set_icon("'.$value->icon.'");
              
              // kita set dulu koordinat markernya
              var point = new google.maps.LatLng(parseFloat(x['.$i.']),parseFloat(y['.$i.']));

              // disini kita masukin konten yang akan ditampilkan di InfoWindow
              var contentString = "<table>"+
                                          "<tr>"+
                                              "<td align=center><img class=img-responsive width=150px src=" + foto['.$i.'] + "></td>"+
                                          "</tr>"+
                                          "<tr>"+
                                              "<td align=center><br><b>" + nama['.$i.'] + "</b></td>"+
                                          "</tr>"+
                                          "<tr>"+
                                              "<td align=center width=300px>" + alamat['.$i.'] + "</td>"+
                                          "</tr>"+
                                          "<tr>"+
                                              "<td align=center> Telp: " + hp['.$i.'] + "</td>"+
                                          "</tr>"+
                                      "</table>";

              var infowindow = new google.maps.InfoWindow({
                  content: contentString
              });
              

              tanda = new google.maps.Marker({
                      position: point,
                      map: peta,
                      icon: gambar_tanda,
                      clickable: true
                  });
              
             
              // nah, disini kita buat marker dan infowindow-nya kedalam array
              markers.push(tanda);
              info.push(infowindow);

              // ini fungsi untuk menampilkan konten infowindow kalo markernya diklik
              google.maps.event.addListener(markers['.$i.'], "click", function() { info['.$i.'].open(peta,markers['.$i.']); });

              ';

      
          $i++;  
      }

      // kita tampilin deh output jsnya :D
      echo $js;
      ?>
      
      // nah untuk yang satu ini...kita push semua markernya kedalam array untuk dikelompokan
      var markerCluster = new MarkerClusterer(peta, markers);
      
  }

  // fungsi inilah yang akan menampilkan gambar ikon sesuai dengan kategori markernya sendiri
  function set_icon(ikon){
      if (ikon == "") {
      } else {
          gambar_tanda = baseurl+"uploads/icon/"+ikon;
      }
  }

</script>
</head>
<body class="hold-transition skin-green sidebar-mini"  onload="peta_awal()">

<div class="wrapper">

    <header class="main-header">
        <!-- Logo -->
        <a href="<?=base_url().'dashboard/' ?>" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>A</b>LT</span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b> SIG</b>Dokter</span>
        </a>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?=base_url().'assets/' ?>dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <!-- <p><?=$this->session->userdata('nama') ?></p> -->
              <p>Administrator</p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <!-- search form -->
          <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
              <input type="text" name="q" class="form-control" placeholder="Search...">
                  <span class="input-group-btn">
                    <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                    </button>
                  </span>
            </div>
          </form>
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="treeview">
              <a href="<?=base_url().'admin/index' ?>">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              </a>
            </li>
            <li class="treeview">
              <a href="<?=base_url().'admin/profil' ?>">
                <i class="fa fa-dashboard"></i> <span>Profil</span>
              </a>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-files-o"></i>
                <span>Master Data</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?=base_url().'admin/dokter' ?>"><i class="fa fa-circle-o"></i> Dokter</a></li>
                <li><a href="<?=base_url().'admin/kategori' ?>"><i class="fa fa-circle-o"></i> Kategori</a></li>
                <li><a href="<?=base_url().'admin/berita' ?>"><i class="fa fa-circle-o"></i> Berita</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="<?=base_url().'admin/komentar' ?>">
                <i class="fa fa-laptop"></i>
                <span>Komentar</span>
              </a>
            </li>
            <li class="header">Front End</li>
            <li><a href="<?=base_url() ?>" target="_blank"><i class="fa fa-eye text-green"></i> <span>View Site</span></a></li>
            <li class="header">A U T H</li>
            <li><a href="<?=base_url().'index.php/auth/change_password' ?>"><i class="fa fa-circle-o text-red"></i> <span>Ubah Passowrd</span></a></li>
            <li><a href="<?=base_url().'index.php/auth/logout' ?>"><i class="fa fa-circle-o text-red"></i> <span>Logout</span></a></li>
          </ul>
        </section>
        <!-- /.sidebar -->
    </aside>

    <section id="main-content">
        <div class="content-wrapper" style="min-height: 394px; padding:15px;">
            <!-- page start-->
            <?php echo $contents; ?>
            <!-- page end-->
        </div>
    </section>
    
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0
        </div>
        <strong>Copyright &copy; 2018</strong> <a href="<?=base_url() ?>">Sistem Informasi Geografis Dokter Mata & Umum, Kabupaten Pemalang</a>. All rights
        reserved.
    </footer>
</div>
<!-- ./wrapper -->

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA1Wo4NQC0L4dzc9Cj6YybH-t0SRGr-EG8"
        type="text/javascript">
</script>
<!-- jQuery 2.2.3 -->
<script src="<?=base_url().'assets/' ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?=base_url().'assets/' ?>bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="<?=base_url().'assets/' ?>plugins/select2/select2.full.min.js"></script>
<!-- DataTables -->
<script src="<?=base_url().'assets/' ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?=base_url().'assets/' ?>plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url().'assets/' ?>dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url().'assets/' ?>dist/js/demo.js"></script>
<script src="<?=base_url().'assets/' ?>dist/js/sweetalert.min.js"></script>
<!-- Page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });

    //Initialize Select2 Elements
    $(".select2").select2();
  });
</script>
</body>
</html>