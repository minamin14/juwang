<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    <?= $page;?>
  </h1>
</section>

<!-- Main content -->
<section class="content">

<div class="row">
  <div class="col-md-12">
    <div class="box box-success">
  <div class="box-header with-border">
    <h3 class="box-title">Tambah Lokasi Dokter</h3>
  </div>
  <!-- /.box-header -->
  <!-- form start -->

   <form role="form" method="POST" enctype="multipart/form-data" action="<?= base_url() ?>admin/simpan_dokter">
    <div class="box-body">
      <div class="form-group">
        <label>NO SIP</label>
        <input name="no_sip" type="text" class="form-control" placeholder="Nomer SIP" required="">
      </div>
      <div class="form-group">
        <label>Nama Dokter</label>
        <input name="nama" type="text" class="form-control" placeholder="Nama dokter" required="">
      </div>
      <div class="form-group">
        <label>Jenis Kelamin</label>
        <select class="form-control select2" name="jenis_kelamin" required="">
            <option default selected value="">Pilih Jenis Kelamin</option>
            <option value="Laki-laki">Laki-laki</option>
            <option value="Perempuan">Perempuan</option>
        </select>
      </div>
      <div class="form-group">
        <label>Kategori</label>
        <option default selected value="">Pilih Praktek</option>
        <select name="id_kategori" class="form-control select2" style="width: 100%;">
          <?php foreach ($kategori as $a): ?>

              <option value="<?php echo $a->id_kategori; ?>"><?php echo $a->nama_kategori; ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Hari Praktek</label>
        <textarea name="hari_praktek" class="form-control" placeholder="Hari Praktek" required=""></textarea>
      </div>
      <div class="form-group">
        <label>Jam Praktek</label>
        <textarea name="jam_praktek" class="form-control" placeholder="Jam Praktek" required=""></textarea>
      </div>
      <div class="form-group">
        <label>Asuransi</label>
        <select class="form-control select2" name="pelayanan" required="">
            <option default selected value="">Pilih Asuransi</option>
            <option value="BPJS">BPJS</option>
            <option value="NON-BPJS">NON-BPJS</option>
        </select>
      </div>
      <div class="form-group">
        <label>Alamat</label>
        <textarea name="alamat" class="form-control" placeholder="Alamat" required=""></textarea>
      </div>
      <div class="form-group">
        <label>Telp/HP</label>
        <input name="hp" type="text" class="form-control" placeholder="Telepon/HP" required="">
      </div>
      <div class="form-group">
        <label>Latitude</label>
        <input name="latitude" type="text" class="form-control" placeholder="-3.0291407" required="">
      </div>
      <div class="form-group">
        <label>Longitude</label>
        <input name="longitude" type="text" class="form-control" placeholder="120.2085258" required="">
      </div>
      <div class="form-group"> 
          <label>Foto</label>
          <img id="preview_gambar" src="<?= base_url() ?>uploads/preview.png" alt="" class="img-responsive thumbnail" />
      </div>
      <div class="form-group">                                
          <input style="padding:0px" type="file" name="foto" onchange="readURL(this);"  id="uni_file" class="uni_style form-control" accept="image/*"/>
      </div>
    </div>

    <div class="box-footer">
      <button name="simpan" type="submit" class="btn btn-success btn-flat"><i class="fa fa-save"></i> Simpan</button>
      <a href="<?=base_url().'admin/dokter' ?>" class="btn btn-warning btn-flat"><i class="fa fa-retweet"></i> Kembali</a>
    </div>
  </form>
</div>
<!-- /.box -->

  </div>
</div>
<!-- /.row -->

</section>
<script src="<?=base_url().'assets/' ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<script>
                                //gambar
                                function readURL(input) { // Mulai membaca inputan gambar
                                    if (input.files && input.files[0]) {
                                        var reader = new FileReader(); // Membuat variabel reader untuk API FileReader

                                        reader.onload = function (e) { // Mulai pembacaan file
                                            $('#preview_gambar') // Tampilkan gambar yang dibaca ke area id #preview_gambar
                                                    .attr('src', e.target.result)
                                                    .height(200)
                                                    .width(200);

                                        };

                                        reader.readAsDataURL(input.files[0]);
                                    }
                                }

</script>
<!-- /.content -->
