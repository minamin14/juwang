
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    <?= $page;?>
  </h1>
</section>

<!-- Main content -->
<section class="content">
      <?php if ($this->session->flashdata('sukses_hapus')) { ?>
        <div class="alert alert-info alert-dismissable" role="">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-trash"> <?php echo $this->session->flashdata('sukses_hapus'); ?></i></h5>
        </div>
    <?php }; ?>

  <div class="row">
    <div class="col-md-12">
      <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">Daftar Komentar</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
            <tr>
              <th>No</th>
              <th width="20%">Nama</th>
              <th width="15%">Email</th>
              <th width="15%">Website</th>
              <th width="40%">Isi Komentar</th>
              <th width="10%">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $no=1; foreach($k as $r){ ?>
            <tr>
              <td><?=$no; ?></td>
              <td><?=$r->nama ?></td>
              <td><?=$r->email ?></td>
              <td><?php if($r->website!=NULL){echo $r->website;}else{echo "-";} ?></td>
              <td><?=$r->komentar ?></td>
              <td>
              <div class="btn-group">
                <a class="btn btn-success btn-sm btn-flat" onclick="alert('Maaf, komentar tidak dapat diedit!')" href="#"><i class="fa fa-edit"></i> </a>
                <a class="btn btn-danger btn-sm btn-flat btn-hapus" data-id="<?= $r->id_komentar ?>" data-nama="<?= $r->nama ?>"><i class="fa fa-trash"></i> </a>
              </div>
              </td>
            </tr>
            <?php $no++; } ?>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->

    </div>
  </div>
  <!-- /.row -->

</section>
<script src="<?=base_url().'assets/' ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<script>
    
    $('.btn-hapus').click(function () {
        var no = $(this).attr('data-id');
        var nama = $(this).attr('data-nama');
        swal({
            title: "Apakah anda yakin?",
            text: "Anda akan menghapus data : " + no + " - " + nama,
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Ya, Hapus!",
            closeOnConfirm: false
        },
                function () {
                    window.location.href = "<?= base_url() ?>admin/hapus_komentar/" + no;
                });
    });

</script> 
