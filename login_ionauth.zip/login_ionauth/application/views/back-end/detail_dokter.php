
<section class="content-header">
    <h1>
        <?= $page;?>
    </h1>
</section>

<!-- Main content -->
<section class="content">

    <div class="row">
        <div class="col-md-6">

            <!-- Profile Image -->
            <div class="box box-primary">
                <div class="box-body box-profile">
                    <img  height="250" width="250" id="preview_gambar" src="<?php echo base_url() . "/uploads/instansi/" . $detail_dokter['foto']; ?>" alt="" class="img-responsive thumbnail" style="display: block; margin: auto;"/>

                    <h3 class="profile-username text-center"><?= $detail_dokter['hari_praktek'] ?></h3>
                    <h3 class="profile-username text-center"><?= $detail_dokter['jam_praktek'] ?></h3>
                    
                </div>
                <!-- /.box-body -->
            </div>

            <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Lokasi</h3>
            </div>
            <!-- /.box-header -->
            <?php echo $map['js'];?>
            <div class="box-body">
              <?php echo $map['html'];?>
              
            </div>
            <!-- /.box-body -->
          </div>

        </div>
        <!-- /.col -->
        <div class="col-md-6">
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#activity" data-toggle="tab">Data Dokter</a></li>
                </ul>
                <div class="tab-content">
                    <div class="active tab-pane" id="activity">
                        <div class="post">
                            <div class="box-header with-border">
                                <h3 class="box-title">Profil Dokter | <?= $detail_dokter['nama'] ?></h3>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body">
                                <strong><i class="fa fa-code margin-r-5"></i> NO SIP</strong>
                                <p class="text-muted">
                                    <?= $detail_dokter['no_sip'] ?>
                                </p>

                                <hr>
                                <strong><i class="fa fa-genderless margin-r-5"></i> Jenis Kelamin</strong>
                                <p class="text-muted">
                                    <?= $detail_dokter['jenis_kelamin'] ?>
                                </p>

                                <hr>
                                <strong><i class="fa fa-university margin-r-5"></i> Jenis Praktek</strong>
                                <p class="text-muted">
                                    <?= $detail_dokter['nama_kategori'] ?>
                                </p>

                                <hr>
                                <strong><i class="fa fa-money margin-r-5"></i> Asuransi</strong>
                                <p class="text-muted">
                                    <?= $detail_dokter['pelayanan'] ?>
                                </p>

                                <hr>
                                <strong><i class="fa fa-map-marker margin-r-5"></i> Alamat</strong>
                                <p class="text-muted">
                                    <?= $detail_dokter['alamat'] ?>
                                </p>

                                <hr>
                                <strong><i class="fa fa-map-marker margin-r-5"></i> Telp/HP</strong>
                                <p class="text-muted">
                                    <?= $detail_dokter['hp'] ?>
                                </p>
                            </div>
                            <!-- /.box-body -->
                        </div> 
                        <div class="box-footer">
                            <?php echo anchor('admin/dokter', 'Kembali', array('class' => 'btn btn-danger')); ?>
                        </div>
                    </div>
                </div>
                <!-- /.tab-content -->
            </div>
            <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->

</section>
