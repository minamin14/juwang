<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    <?= $page;?>
  </h1>
</section>

<!-- Main content -->
<section class="content">

<div class="row">
  <div class="col-md-12">
    <div class="box box-success">
  <div class="box-header with-border">
    <h3 class="box-title">Tambah Lokasi Dokter</h3>
  </div>
  <!-- /.box-header -->
  <!-- form start -->

   <form role="form" method="POST" enctype="multipart/form-data" action="<?= base_url() ?>admin/coba">
    <div class="box-body">
      <div class="form-group">
        <label>NO SIP</label>
        <input name="no_sip" type="text" class="form-control" value="<?php echo $dokter['no_sip']; ?>"required>
        <input name="id_dokter" type="hidden" class="form-control" value="<?php echo $dokter['id_dokter']; ?>"required>
      </div>
      <div class="form-group">
        <label>Nama Dokter</label>
        <input name="nama" type="text" class="form-control" value="<?php echo $dokter['nama']; ?>" required>
      </div>
      <div class="form-group">
        <label>Jenis Kelamin</label>
        <select class="form-control select2" name="jenis_kelamin" required>
            <option default selected value="">Pilih Jenis Kelamin</option>
            <option <?= ($dokter['jenis_kelamin'] == "Laki-laki") ? "selected" : "" ?> value="Laki-laki">Laki-laki</option>
            <option <?= ($dokter['jenis_kelamin'] == "Perempuan") ? "selected" : "" ?> value="Perempuan">Perempuan</option>
        </select>
      </div>
      <div class="form-group">
        <label>Kategori</label>
        <select name="id_kategori" class="form-control select2" style="width: 100%;">
          <option default selected value="">Pilih Praktek</option>
          <?php foreach ($kategori as $a): ?>

              <option  <?= ($dokter['id_kategori'] == $a->id_kategori) ? "selected" : "" ?> value="<?php echo $a->id_kategori; ?>"><?php echo $a->nama_kategori; ?>
                
              </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Hari Praktek</label>
        <textarea name="hari_praktek" class="form-control" required=""><?= $dokter['hari_praktek'] ?></textarea>
      </div>
      <div class="form-group">
        <label>Jam Praktek</label>
        <textarea name="jam_praktek" class="form-control"  required=""><?= $dokter['jam_praktek'] ?></textarea>
      </div>
      <div class="form-group">
        <label>Asuransi</label>
        <select class="form-control select2" name="pelayanan" required="">
            <option default selected value="">Pilih Asuransi</option>
            <option <?= ($dokter['pelayanan'] == "BPJS") ? "selected" : "" ?> value="BPJS">BPJS</option>
            <option <?= ($dokter['pelayanan'] == "NON-BPJS") ? "selected" : "" ?> value="NON-BPJS">NON-BPJS</option>
        </select>
      </div>
      <div class="form-group">
        <label>Alamat</label>
        <textarea name="alamat" class="form-control" required=""><?= $dokter['alamat'] ?></textarea>
      </div>
      <div class="form-group">
        <label>Telp/HP</label>
        <input name="hp" type="text" class="form-control" value="<?= $dokter['hp'] ?>" required="">
      </div>
      <div class="form-group">
        <label>Latitude</label>
        <input name="latitude" type="text" class="form-control" value="<?= $dokter['latitude'] ?>" required="">
      </div>
      <div class="form-group">
        <label>Longitude</label>
        <input name="longitude" type="text" class="form-control" value="<?= $dokter['longitude'] ?>" required="">
      </div>
      <div class="form-group"> 
          <label>Foto</label>
          <img height="200" width="200" id="preview_gambar" src="<?php echo base_url() . "/uploads/instansi/" . $dokter['foto']; ?>" alt="" class="img-responsive thumbnail" />
      </div>
      <div class="form-group">
        <label>Ikon</label>
       <input style="padding:0px" type="file" name="foto" onchange="readURL(this);" id="uni_file" class="uni_style form-control" accept="image/*"/>
        <p class="help-block">Maks Size 1MB</p>
      </div>
    </div>

    <div class="box-footer">
      <button name="simpan" type="submit" class="btn btn-success btn-flat"><i class="fa fa-save"></i> Simpan</button>
      <a href="<?=base_url().'admin/dokter' ?>" class="btn btn-warning btn-flat"><i class="fa fa-retweet"></i> Kembali</a>
    </div>
  </form>
</div>
<!-- /.box -->

  </div>
</div>
<!-- /.row -->

</section>
<script src="<?=base_url().'assets/' ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<script>
                                //gambar
                                function readURL(input) { // Mulai membaca inputan gambar
                                    if (input.files && input.files[0]) {
                                        var reader = new FileReader(); // Membuat variabel reader untuk API FileReader

                                        reader.onload = function (e) { // Mulai pembacaan file
                                            $('#preview_gambar') // Tampilkan gambar yang dibaca ke area id #preview_gambar
                                                    .attr('src', e.target.result)
                                                    .height(200)
                                                    .width(200);

                                        };

                                        reader.readAsDataURL(input.files[0]);
                                    }
                                }

</script>
<!-- /.content -->
