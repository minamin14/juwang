
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    <?= $page;?>
  </h1>
</section>

<!-- Main content -->
<section class="content">

  <div class="row">
    <div class="col-sm-10">
      <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">Ubah Berita</h3>
        </div>
        <!-- /.box-header -->
        <form role="form" method="POST" enctype="multipart/form-data" action="<?= base_url() ?>admin/ubah_berita">
        <div class="box-body">
          <div class="form-group">
            <label>Judul</label>
            <input name="id_berita" type="hidden" value="<?=$berita['id_berita'] ?>">
            <input name="judul" type="text" class="form-control" value="<?=$berita['judul'] ?>" style="width:50%;">
          </div>
          <div class="form-group">
            <label>Isi Berita</label>
            <textarea name="isi_berita" class="form-control ckeditor" rows="5" ><?=$berita['isi_berita'] ?></textarea>
          </div>
          <div class="form-group"> 
              <label>Foto</label>
              <img height="200" width="200" id="preview_gambar" src="<?php echo base_url() . "/uploads/berita/" . $berita['gambar']; ?>" alt="" class="img-responsive thumbnail" />
          </div>
          <div class="form-group">
              <input style="padding:0px" type="file" name="gambar" onchange="readURL(this);" id="uni_file" class="uni_style form-control" accept="image/*"/>
              <p class="help-block">Maks Size 1MB</p>
          </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <button name="update" type="submit" class="btn btn-success btn-flat"><i class="fa fa-save"></i> Update</button>
        <a href="<?=base_url().'admin/berita' ?>" class="btn btn-warning btn-flat"><i class="fa fa-retweet"></i> Kembali</a>
        </div>
      </div>
      </form>
      <!-- /.box -->
    </div>
  </div>
  <!-- /.row -->

</section>
<script>
//gambar
function readURL(input) 
{ // Mulai membaca inputan gambar
    if (input.files && input.files[0]) {
        var reader = new FileReader(); // Membuat variabel reader untuk API FileReader

        reader.onload = function (e) { // Mulai pembacaan file
            $('#preview_gambar') // Tampilkan gambar yang dibaca ke area id #preview_gambar
                    .attr('src', e.target.result)
                    .height(200)
                    .width(200);

        };

        reader.readAsDataURL(input.files[0]);
    }
}

</script>
<!-- /.content -->
