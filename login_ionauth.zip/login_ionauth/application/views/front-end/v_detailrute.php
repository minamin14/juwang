

<div class="col-sm-4 sidebar" style="padding-right:20px;">
  <div class="panel">
    <div class="panel-heading">
      <h3 class="panel-title">Rute</h3>
    </div>
    <div class="panel-body">
      <div id="directionsDiv"></div>

      
    </div>
  </div>

</div>
<!-- ./SIDEBAR -->


<div class="col-sm-8 content">
  <div class="panel">
    <div class="panel-heading">
      <h3 class="panel-title">Peta</h3>
    </div>
    <div class="panel-body" style="padding:0;">
      <?php echo $map['js'];?>
      <div class="detailberita">
              <?php echo $map['html'];?>
          
      </div>
    </div>
    <div class="panel-heading">
      <h3 class="panel-title">Info Tempat Praktek</h3>
    </div>
    <div class="panel-body" style="padding:0;">
      <div class="detailberita">
        <strong><i class="fa fa-laptop margin-r-5"></i> Foto</strong>
            <p class="text-muted">
                <img  height="250" width="250" id="preview_gambar" src="<?php echo base_url() . "/uploads/instansi/" . $detail_dokter['foto']; ?>" alt="" class="img-responsive thumbnail" style="display: block; margin: auto;"/>
            </p>

            <hr>
          <strong><i class="fa fa-code margin-r-5"></i> NO SIP</strong>
            <p class="text-muted">
                <?= $detail_dokter['no_sip'] ?>
            </p>

            <hr>
            <strong><i class="fa fa-genderless margin-r-5"></i> Jenis Kelamin</strong>
            <p class="text-muted">
                <?= $detail_dokter['jenis_kelamin'] ?>
            </p>

            <hr>
            <strong><i class="fa fa-university margin-r-5"></i> Jenis Praktek</strong>
            <p class="text-muted">
                <?= $detail_dokter['nama_kategori'] ?>
            </p>

            <hr>
            <strong><i class="fa fa-money margin-r-5"></i> Asuransi</strong>
            <p class="text-muted">
                <?= $detail_dokter['pelayanan'] ?>
            </p>

            <hr>
            <strong><i class="fa fa-map-marker margin-r-5"></i> Alamat</strong>
            <p class="text-muted">
                <?= $detail_dokter['alamat'] ?>
            </p>

            <hr>
            <strong><i class="fa fa-calendar margin-r-5"></i> Hari Praktek</strong>
            <p class="text-muted">
                <?= $detail_dokter['hari_praktek'] ?>
            </p>

            <hr>
            <strong><i class="fa fa-clock-o margin-r-5"></i> Jam Praktek</strong>
            <p class="text-muted">
                <?= $detail_dokter['jam_praktek'] ?>
            </p>

            <hr>
            <strong><i class="fa fa-map-marker margin-r-5"></i> Telp/HP</strong>
            <p class="text-muted">
                <?= $detail_dokter['hp'] ?>
            </p>
      </div>
    </div>
  </div>
</div>
<!-- ./CONTENT -->