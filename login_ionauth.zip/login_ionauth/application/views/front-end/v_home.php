      

      <div class="col-sm-4 sidebar">
        <div class="panel">
          <div class="panel-heading">
            <h3 class="panel-title">Daftar Dokter</h3>
          </div>
          <div class="panel-body">
            <?php foreach ($list_dokter->result() as $l) { ?>
              <blockquote style="padding:0 10px;">
                <p><?=$l->nama ?></p>
                <footer><?=$l->alamat ?> <cite title="Source Title"><?=$l->hp ?></cite></footer>
              </blockquote>
            <?php } ?>
            <a class="btn btn-warning btn-flat" style="float:right;" href="<?=base_url().'web/lokasi' ?>"><i class="fa fa-eye"></i> View all location</a>
          </div>
        </div>

      </div>
      <!-- ./SIDEBAR -->

      <div class="col-sm-8 content">
        <div class="panel">
          <!-- <div class="panel-heading">
            <h3 class="panel-title">Peta Lokasi</h3>
          </div> -->
          <div class="panel-body" style="border:1px solid #ddd;padding: 0;">
            
            <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA1Wo4NQC0L4dzc9Cj6YybH-t0SRGr-EG8"
            type="text/javascript"></script>
                  
            <div id="map_canvas" style="width: auto; height: 600px;"></div>
      
          </div>
        </div>
      </div>
      <!-- ./CONTENT -->

      <!-- <div class="col-sm-12 banner"> -->
        <!-- <img src=" echo base_url().'uploads/banners/no-banner-728x90.jpg' ?>"> -->
      <!-- </div> -->

      <div class="col-sm-12 top-footer">
        <div class="col-sm-4 left">
          <div class="panel">
            <div class="panel-heading">
              <h3 class="panel-title">Berita Terbaru</h3>
            </div>
            <div class="panel-body">
            <?php
            foreach($bt->result() as $r){ ?>
              <div class="media">
                <div class="media-left media-top">
                  <a href="<?=base_url().'web/beritadetail/'.$r->id_berita ?>">
                    <img class="media-object" src="<?=base_url().'uploads/berita/'.$r->gambar ?>" width="64">
                  </a>
                </div>
                <div class="media-body">
                  <h4 class="media-heading"><a href="<?=base_url().'web/beritadetail/'.$r->id_berita ?>"><?=$r->judul ?></a> </h4>
                  <?=substr($r->isi_berita, 0,45)."..." ?>
                </div>
              </div>
              <?php } ?>
            </div>
          </div>
        </div>
        <div class="col-sm-4 center">
          <div class="panel">
            <div class="panel-heading">
              <h3 class="panel-title">Berita Popular</h3>
            </div>
            <div class="panel-body">
            <?php
            foreach($bp->result() as $bp){ ?>
              <div class="media">
                <div class="media-left media-top">
                  <a href="<?=base_url().'web/beritadetail/'.$bp->id_berita ?>">
                    <img class="media-object" src="<?=base_url().'uploads/berita/'.$bp->gambar ?>" width="64">
                  </a>
                </div>
                <div class="media-body">
                  <h4 class="media-heading"><a href="<?=base_url().'web/beritadetail/'.$r->id_berita ?>"><?=$bp->judul ?></a> </h4>
                  <?=substr($bp->isi_berita, 0,45)."..." ?>
                </div>
              </div>
              <?php } ?>
            </div>
          </div>
        </div>
        <div class="col-sm-4 right">
          <div class="panel">
            <div class="panel-heading">
              <h3 class="panel-title">Contact</h3>
            </div>
            <div class="panel-body">
              <address>
                <strong>Alamat</strong><br>
                Jl. Maju Mundur, Kel. Anu, Kec. Anu 91921<br>
                Kab. Situ - Kota Sana
              </address>

              <address>
                <abbr title="Phone">P :</abbr> (+62) 87654 876534<br>
                <abbr title="Phone">M :</abbr> <a href="mailto:#">anu@gmail.com</a><br>
                <abbr title="Phone">W :</abbr> <a href="http://google.com">Google</a>
              </address>
            </div>
          </div>
        </div>
      </div><!-- ./ TOP-FOOTER -->
