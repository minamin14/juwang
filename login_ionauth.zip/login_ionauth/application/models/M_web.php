<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_web extends CI_Model {

	public function lokasi(){
		return $this->db->get('lokasi');
	}

	public function detail_lokasi($id){
		$this->db->where('id', $id);
        return $this->db->get('lokasi');
	}

	public function lokasi2(){
		$this->db->group_by('nama', 'asc');
		$this->db->limit(5);
        return $this->db->get('lokasi');
	}

	public function list_dokter(){
		$this->db->order_by('nama', 'asc');
        return $this->db->get('dokter');
	}

	public function dokter(){
		$this->db->select("*");
        $this->db->from('dokter d');
        $this->db->join('kategori_praktek k', 'd.id_kategori = k.id_kategori');
        return $this->db->get();
	}

	public function detail_dokter($id_dokter){
		$this->db->where('id_dokter', $id_dokter);
        return $this->db->get('dokter');
	}

	public function berita(){
		$this->db->group_by('id_berita', 'asc');
		$this->db->limit(3);
        return $this->db->get('berita');
	}

	public function detail_berita($id){
		 $this->db->where('id_berita', $id);
        return $this->db->get('berita');
	}

	public function berita_populer(){
		$this->db->group_by('dibaca');
		$this->db->limit(3);
        return $this->db->get('berita');
	}

	public function berita_terbaru(){
		$this->db->group_by('id_berita');
		$this->db->limit(3);
        return $this->db->get('berita');
	}

	public function profil(){
		 $this->db->where('id_profil', '1');
        return $this->db->get('profil');
	}

	public function komentar(){
		$this->db->group_by('id_komentar');
		$this->db->limit(3);
        return $this->db->get('komentar');
	}

	

}

/* End of file M_web.php */
/* Location: ./application/models/M_web.php */