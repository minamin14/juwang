<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_admin extends CI_Model {

	public function profil(){
		$this->db->where('id_profil', '1');
        return $this->db->get('profil');
	}

	public function ubah_profil($data, $id){
		$this->db->where('id_profil', $id);
        $this->db->update('profil', $data);
	}

	public function list_dokter(){
		$this->db->select("*");
        $this->db->from('dokter d');
        $this->db->join('kategori_praktek k', 'd.id_kategori = k.id_kategori');
        return $this->db->get();
	}

	public function list_kategori(){
		return $this->db->get('kategori_praktek');
	}

	public function cek_no_sip($no_sip) {
        $this->db->where('no_sip', $no_sip);
        return $this->db->get('dokter');
    }

    public function cari_dokter($id_dokter){
    	$this->db->where('id_dokter', $id_dokter);
        return $this->db->get('dokter');
    }

    public function rute($id_dokter){
        return $this->db->get_where('dokter', array('id_dokter'=>$id_dokter))->row();
    }

    public function detail_dokter($id_dokter){
    	$this->db->select("*");
        $this->db->from('dokter d');
        $this->db->join('kategori_praktek k', 'd.id_kategori = k.id_kategori');
    	$this->db->where('d.id_dokter', $id_dokter);
        return $this->db->get();
    }

    public function coba($id_dokter) {

        return $this->db->get_where("dokter", array('id_dokter' => $id_dokter));
    }

    public function edit_dokter($data, $id_dokter) {
        $this->db->where('id_dokter', $id_dokter);
        $this->db->update('dokter', $data);
    }

    public function hapus_dokter($id_dokter) {
        $this->db->where('id_dokter', $id_dokter);
        $this->db->delete('dokter');
    }

    public function simpan_dokter($data) {
        $this->db->insert('dokter', $data);
    }

    public function simpan_kategori($data) {
        $this->db->insert('kategori_praktek', $data);
    }

    public function cari_kategori($id_kategori){
        $this->db->where('id_kategori', $id_kategori);
        return $this->db->get('kategori_praktek');
    }

    public function coba2($id_kategori) {

        return $this->db->get_where("kategori_praktek", array('id_kategori' => $id_kategori));
    }

    public function ubah_kategori($data, $id_kategori) {
        $this->db->where('id_kategori', $id_kategori);
        $this->db->update('kategori_praktek', $data);
    }

    public function hapus_kategori($id_kategori) {
        $this->db->where('id_kategori', $id_kategori);
        $this->db->delete('kategori_praktek');
    }

    public function list_berita(){
        return $this->db->get('berita');
    }

    public function detail_berita($id_berita){
        $this->db->where('id_berita', $id_berita);
        return $this->db->get('berita');
    }

    public function simpan_berita($data) {
        $this->db->insert('berita', $data);
    }

    public function ubah_berita($data, $id_berita) {
        $this->db->where('id_berita', $id_berita);
        $this->db->update('berita', $data);
    }

    public function coba3($id_berita) {

        return $this->db->get_where("berita", array('id_berita' => $id_berita));
    }

    public function hapus_berita($id_berita) {
        $this->db->where('id_berita', $id_berita);
        $this->db->delete('berita');
    }

    public function komentar(){
        return $this->db->get('komentar');
    }

    public function hapus_komentar($id_komentar) {
        $this->db->where('id_komentar', $id_komentar);
        $this->db->delete('komentar');
    }

	

}

/* End of file M_admin.php */
/* Location: ./application/models/M_admin.php */